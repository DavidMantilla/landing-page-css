<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="./css/normalize.css">
    <link rel="stylesheet" href="./css/estilos.css">
    <!-- NOMBRE DE LA PESTAÑA-->
    <title>Panel de control</title>
</head>
</body>
<!-- contenedor de la pagina comienza con la sentencia <div id="wrapper">-->
<div id="wrapper">
    <?php include 'layout/header.php'; ?>

    <main class="main">
    <?php include 'layout/sidebar.php'; ?>
    <div class="main-content">
        <div class="row">
            <div class="card" style="border-color: #16AF89;">
                <div class="card-body">
                    <p><strong>producto más vendido</strong></p>
                    <img src="imagenes/productomasvendido.svg" alt="" srcset="" width="30px" class="icon-card">
                    <span class="color:#16AF89"><?php echo ('nombredelproducto') ?></span>
                </div>
            </div>
            <div class="card" style="border-color: #B68117;">
                <div class="card-body">
                    <p><strong>Ganancias</strong></p>
                    <img src="imagenes/ganancias.svg" alt="" srcset="" width="30px" class="icon-card">
                    <span class="color:#B68117"><?php echo ('precio') ?></span>
                </div>
            </div>
            <div class="card" style="border-color: #EC6273;">
                <div class="card-body">
                    <p><strong>Solicitudes pendientes</strong></p>
                    <img src="imagenes/solicitudespendientes.svg" alt="" srcset="" width="30px" class="icon-card">
                    <span class="color:#EC6273"><?php echo ('cantidades') ?></span>
                </div>
            </div>
        </div>

        <div class="row">
            <div class="card wide-card" style="border-color: #A955CF;">
                <div class="card-body">
                    <p><strong>Resumen de ganancias</strong></p>
                    <span class="color:#A955CF"><?php echo ('Cantidad') ?></span>
                </div>
            </div>
            <div class="card equal-height-card" style="border-color: #4A93E9;">
                <div class="card-body">
                    <p><strong>Reabastecimiento</strong></p>
                    <img src="imagenes/puntodeproducto.svg" alt="" srcset="" width="30px" class="icon-card">
                    <span class="color:#4A93E9"><?php echo ('producto') ?></span>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</body>
</html>