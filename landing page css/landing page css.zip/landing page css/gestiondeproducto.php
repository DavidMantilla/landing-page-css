<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="stylesheet" href="./css/normalize.css">
    <link rel="stylesheet" href="./css/estilos.css">
    <!-- NOMBRE DE LA PESTAÑA-->
    <title>Gestion de producto</title>
</head>
</body>
<!-- contenedor de la pagina comienza con la sentencia <div id="wrapper">-->
<div id="wrapper">
    <?php include 'layout/header.php'; ?>

    <main class="main">
    <?php include 'layout/sidebar.php'; ?>
    <div class="main-content">
        <div class="busqueda">
            <input type="text" name="buscador" id="buscador"placeholder="buscar articulos...">
            <!--<ul id="listaArticulos">
                <li class="articulo">hola</li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
                <li class="articulo"></li>
            </ul> -->
            <button class="categoria-btn" id="categoria-btn">
                Categoria
                <img src="imagenes/categoria.svg" alt="logo-1" class="categoria-logo">
            </button>
        </div>
        <div class="row">
            <div class="card-2" style="border-color: #16AF89;">
                <div class="card-body-2">
                    <div class="card-imagen"></div>
                    <h2><strong>Nombre</strong></h2>
                    <img src="imagenes/editar.svg" alt="" srcset="" width="30px" class="icon-card">
                    <p><strong>Categoria</strong></p>
                    <p><strong>Cantidad</strong></p>
                    <h2><strong>Descripcion</strong></h2>
                    <div class="card-descripcion"></div>
                    <img src="imagenes/ganancia.svg" alt="" srcset="" width="30px" class="icon-card-2">
                    <h2><strong>Precio</strong></h2>
                    <span class="color:#16AF89"><?php echo ('nombredelproducto') ?></span>
                </div>
            </div>
            <div class="card-2" style="border-color: #B68117;">
                <div class="card-body-2">
                    <div class="card-imagen"></div>
                    <h2><strong>Nombre</strong></h2>
                    <img src="imagenes/editar.svg" alt="" srcset="" width="30px" class="icon-card">
                    <p><strong>Categoria</strong></p>
                    <p><strong>Cantidad</strong></p>
                    <h2><strong>Descripcion</strong></h2>
                    <div class="card-descripcion"></div>
                    <img src="imagenes/ganancia.svg" alt="" srcset="" width="30px" class="icon-card-2">
                    <h2><strong>Precio</strong></h2>
                    <span class="color:#B68117"><?php echo ('precio') ?></span>
                </div>
            </div>
            <div class="card-2" style="border-color: #EC6273;">
                <div class="card-body-2">
                    <div class="card-imagen"></div>
                    <h2><strong>Nombre</strong></h2>
                    <img src="imagenes/editar.svg" alt="" srcset="" width="30px" class="icon-card">
                    <p><strong>Categoria</strong></p>
                    <p><strong>Cantidad</strong></p>
                    <h2><strong>Descripcion</strong></h2>
                    <div class="card-descripcion"></div>
                    <img src="imagenes/ganancia.svg" alt="" srcset="" width="30px" class="icon-card-2">
                    <h2><strong>Precio</strong></h2>
                    <span class="color:#EC6273"><?php echo ('cantidades') ?></span>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="card-2" style="border-color: #16AF89;">
                <div class="card-body-2">
                    <div class="card-imagen"></div>
                    <h2><strong>Nombre</strong></h2>
                    <img src="imagenes/editar.svg" alt="" srcset="" width="30px" class="icon-card">
                    <p><strong>Categoria</strong></p>
                    <p><strong>Cantidad</strong></p>
                    <h2><strong>Descripcion</strong></h2>
                    <div class="card-descripcion"></div>
                    <img src="imagenes/ganancia.svg" alt="" srcset="" width="30px" class="icon-card-2">
                    <h2><strong>Precio</strong></h2>
                    <span class="color:#16AF89"><?php echo ('nombredelproducto') ?></span>
                </div>
            </div>
            <div class="card-2" style="border-color: #B68117;">
                <div class="card-body-2">
                    <div class="card-imagen"></div>
                    <h2><strong>Nombre</strong></h2>
                    <img src="imagenes/editar.svg" alt="" srcset="" width="30px" class="icon-card">
                    <p><strong>Categoria</strong></p>
                    <p><strong>Cantidad</strong></p>
                    <h2><strong>Descripcion</strong></h2>
                    <div class="card-descripcion"></div>
                    <img src="imagenes/ganancia.svg" alt="" srcset="" width="30px" class="icon-card-2">
                    <h2><strong>Precio</strong></h2>
                    <span class="color:#B68117"><?php echo ('precio') ?></span>
                </div>
            </div>
            <div class="card-2" style="border-color: #EC6273;">
                <div class="card-body-2">
                    <div class="card-imagen"></div>
                    <h2><strong>Nombre</strong></h2>
                    <img src="imagenes/editar.svg" alt="" srcset="" width="30px" class="icon-card">
                    <p><strong>Categoria</strong></p>
                    <p><strong>Cantidad</strong></p>
                    <h2><strong>Descripcion</strong></h2>
                    <div class="card-descripcion"></div>
                    <img src="imagenes/ganancia.svg" alt="" srcset="" width="30px" class="icon-card-2">
                    <h2><strong>Precio</strong></h2>
                    <span class="color:#EC6273"><?php echo ('cantidades') ?></span>
                </div>
            </div>
        </div>
    </div>
</main>
</div>
</body>
</html>