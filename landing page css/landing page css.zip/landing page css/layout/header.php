<header class="header">
    <div class="welcome-text">Bienvenidos</div>
    <div class="cuenta">
        <img class="account" src="./imagenes/perfil.png">
    </div>
</header>