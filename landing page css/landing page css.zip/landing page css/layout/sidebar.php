               <aside class="main-aside">
                    <img class="logo" src="./imagenes/logo2.png" alt="">
                    
                    <!-- MENU -->
                    <ul class="nav-list">
                        <li class="nav-item">
                            <div class="barra"></div>
                                <a class="nav-link" href="./paneldecontrol.php">
                                  <img class="icon icon-paneldecontrol" src="./imagenes/Paneldecontrol.svg" alt="">
                                   Panel de control
                                </a>
                            </li>
                            <li class="nav-item">
                                <div class="barra" style="height: 54px;"></div>
                                    <a class="nav-link active" href="./gestiondeproducto.php">
                                        <img class="icon icon-gestiondeproductos" src="./imagenes/Gestiondeproductos.svg" alt="">
                                         Gestion de productos
                                    </a>
                            </li>
                            <li class="nav-item">
                                <div class="barra"></div>
                                    <a class="nav-link" href="./pedidos.php">
                                       <img class="icon icon-pedidos" src="./imagenes/Pedidos.svg" alt="">
                                       Pedidos
                                    </a>
                            </li>
                            <li class="nav-item">
                                <div class="barra"></div>
                                    <a class="nav-link" href="./suministros.php">
                                        <img class="icon icon-suministros" src="./imagenes/Suministros.svg" alt="">
                                        Suministros
                                    </a>
                            </li>
                            <li class="nav-item">
                                <div class="barra"></div>
                                    <a class="nav-link" href="./soporteyayuda.php">
                                        <img class="icon icon-soporteyayuda" src="./imagenes/Soporteyayuda.svg" alt="">
                                        Soporte y ayuda
                                    </a>
                            </li>
                        </ul>
                                            
                        </li>
                    </ul>
        
            </aside>